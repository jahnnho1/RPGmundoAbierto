window.addEventListener('load', iniciarJuego)
const $ = selector => document.getElementById(selector);
let ataqueJugador;
let ataqueEnemigo;
let resultadoCombate;
let vidaJugador = 3;
let vidaEnemigo = 3;
let estadoEjecuccionJuego = true;

function iniciarJuego() {        
    let seleccionarAtaque =  $('seleccionar-ataque');
    seleccionarAtaque.hidden = true;
    let botonMascota =  $('boton-mascota');
    botonMascota.addEventListener('click', seleccionarMascotaJugador);    
    let botonReiniciar = $('boton-reiniciar');
    botonReiniciar.hidden = true;
    botonReiniciar.addEventListener('click', reiniciarJuego);
}

function seleccionarMascotaJugador(){
    let hipodoge = $('hipodoge');
    let capipepo = $('capipepo');
    let ratigueya = $('ratigueya');
    let spanMascotaJugador = $('mascota-jugador');
    let seleccionarAtaque =  $('seleccionar-ataque');

    if (hipodoge.checked) {
        spanMascotaJugador.innerHTML = 'Hipodoge';
        seleccionarAtaque.hidden = false;
        capipepo.disabled = true;
        ratigueya.disabled  = true;
    } else if (capipepo.checked) {
        spanMascotaJugador.innerHTML = 'Capipepo';
        hipodoge.disabled = true;
        ratigueya.disabled  = true;
        seleccionarAtaque.hidden = false;
    } else if (ratigueya.checked) {
        spanMascotaJugador.innerHTML = 'Ratigueya';
        seleccionarAtaque.hidden = false;
        ratigueya.disabled  = true;
        capipepo.disabled = true;
    } else {
        alert('Selecciona una mascota')
    }

    seleccionarMascotaEnemigo();
}

function seleccionarMascotaEnemigo(){
    let mascotaAleatorio = aleatorio(1,3); 
    let spanMascotaEnemigo = $('mascota-enemigo');

    if(mascotaAleatorio == 1) {
        spanMascotaEnemigo.innerHTML = 'Hipodoge';
    } else if (mascotaAleatorio == 2) {
        spanMascotaEnemigo.innerHTML = 'Capipepo';
    } else {
        spanMascotaEnemigo.innerHTML = 'Ratigueya';
    }
}

function realizarAtaque(tipoAtaque) {
    ataqueJugador = tipoAtaque;

    if(revisarVidas()) {
        ataqueAleatorioEnemigo();
        combate();
        crearMensaje();
        if(!revisarVidas()){
            resultadoBatalla();
        }
    }
}

function ataqueAleatorioEnemigo(){
    let ataqueAleatorio = aleatorio(1,3);

    if(ataqueAleatorio == 1) {
        ataqueEnemigo = 'Fuego';
    } else if(ataqueAleatorio == 1) {
        ataqueEnemigo = 'Agua';
    } else {
        ataqueEnemigo = 'Tierra';
    }
}

function combate() {
    if(ataqueJugador == ataqueEnemigo) {
        resultadoCombate = 'Empate'
    } else { 
        switch(ataqueJugador) {
            case 'Fuego':
                if(ataqueEnemigo == 'Agua') {
                    resultadoCombate = 'Victoria mascota enemiga';
                    vidaJugador--;
                } else {
                    resultadoCombate = 'Victoria mascota aliada';
                    vidaEnemigo--;
                }
                break;
            case 'Agua':
                if(ataqueEnemigo == 'Tierra') {
                    resultadoCombate = 'Victoria mascota enemiga';
                    vidaJugador--;
                } else {
                    resultadoCombate = 'Victoria mascota aliada';
                    vidaEnemigo--;
                }
                break;
            case 'Tierra':
                if(ataqueEnemigo == 'Fuego') {
                    resultadoCombate = 'Victoria mascota enemiga';
                    vidaJugador--;
                } else {
                    resultadoCombate = 'Victoria mascota aliada';
                    vidaEnemigo--;
                }
                break;
        }
        recalcularVidas();
    }
}

function recalcularVidas(){
    spanVidaEnemigo = $('vidas-enemigo');
    spanVidaJugador = $('vidas-jugador');
    spanVidaEnemigo.innerHTML = vidaEnemigo;
    spanVidaJugador.innerHTML = vidaJugador;
}

function revisarVidas(){    
    if(vidaEnemigo <= 0){
        estadoEjecuccionJuego = false;
        bloquearHUD(true);
    } else if (vidaJugador <= 0){
        estadoEjecuccionJuego = false;
        bloquearHUD(true);
    }
    return estadoEjecuccionJuego;
}

function crearMensaje(){
    let sectionMensajes = $('mensajes');
    let parrafo = document.createElement('p');
    parrafo.innerHTML = `tu mascota ataco con ${ataqueJugador}, la mascota del enemigo ataco con ${ataqueEnemigo} resultado del combate es ${resultadoCombate}`;
    sectionMensajes.appendChild(parrafo);
}

function resultadoBatalla(){
    let sectionMensajes = $('mensajes');
    let parrafo = document.createElement('p');
    let victorioso = vidaEnemigo <= 0 ? 'Jugador' : 'Enemigo';
    parrafo.innerHTML = `La batalla a finalizado el resultado final es a favor del ${victorioso}`;
    sectionMensajes.appendChild(parrafo);
    estadoEjecuccionJuego = false;
    let botonReiniciar = $('boton-reiniciar');
    botonReiniciar.hidden = false;
}

function aleatorio(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}

function bloquearHUD(DesactivarHUD){
    let botonMascota =  $('boton-mascota');
    let hipodoge = $('hipodoge');
    let capipepo = $('capipepo');
    let ratigueya = $('ratigueya');
    let fuego = $('boton-fuego');
    let agua = $('boton-agua');
    let tierra = $('boton-tierra');
    botonMascota.disabled = DesactivarHUD;
    hipodoge.disabled = DesactivarHUD;
    capipepo.disabled = DesactivarHUD;
    ratigueya.disabled = DesactivarHUD;
    fuego.disabled = DesactivarHUD;
    agua.disabled = DesactivarHUD;
    tierra.disabled = DesactivarHUD;
}

function reiniciarJuego(){
    location.reload();
}

