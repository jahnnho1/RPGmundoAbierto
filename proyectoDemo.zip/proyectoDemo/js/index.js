let victoriasJugador = 0;
let victoriasPC = 0;

for (var partidasJugadas = 0; partidasJugadas < 3; partidasJugadas++){
    let jugador = 0;
    let pc = Math.floor(Math.random() * 3) + 1;
    jugador = Number(prompt('Elige? 1 piedra, 2 papel, 3 tijera '));
    let tipoDeLanzamiento = ['n/a', 'piedra', 'papel', 'tijera'];
    if (jugador == pc) {
        console.log(` EMPATE jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
    } else {
        switch(jugador) {
        case 1:
            if(pc == 2) {
                console.log(` PERDEDOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasPC++;
            } else {
                console.log(` GANADOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasJugador++;
            }
            break;
        case 2:
            if(pc == 3) {
                console.log(` PERDEDOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasPC++;
            } else {
                console.log(` GANADOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasJugador++;
            }
            break;
        case 3:
            if(pc == 1) {
                console.log(` PERDEDOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasPC++;
            } else {
                console.log(` GANADOR jugador ${tipoDeLanzamiento[jugador]}  pc ${tipoDeLanzamiento[pc]}`);
                victoriasJugador++;
            }
            break;
        }                
    }
}

if(victoriasJugador == victoriasPC) {
    alert(` El resultado final fue un empate ya que el jugador obtuvo ${victoriasJugador} victorias y el pc obtuvo ${victoriasPC} victorias `);
} else if ( victoriasJugador > victoriasPC) {
    alert(` El ganador es el jugador al haber obtenido ${victoriasJugador} victorias `);
} else {
    alert(` El ganador es el PC al haber obtenido ${victoriasPC} victorias `);
}